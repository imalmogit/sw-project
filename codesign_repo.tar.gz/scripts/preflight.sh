#!/bin/bash
# Check everything that could be wrong BEFORE committing two hours to the run.
#
#   scripts/preflight.sh
#
# Takes about a minute. Every check prints PASS or FAIL, and every FAIL prints
# the command that fixes it. Nothing here writes into the repository.
#
# The point of this file: the measurement scripts were proven on an earlier run
# of this project, but scripts/env.sh, scripts/nbody_opt3_regression.sh and the
# repository paths are new. This exercises the new parts, plus the two
# environment traps that have already cost this project time once each: the
# missing Python.h, and perf recording zero samples in silence.
set -u

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
TMP=$(mktemp -d)
trap 'rm -rf "$TMP"' EXIT

PASS=0; FAIL=0; WARN=0
ok()   { printf '  \033[32mPASS\033[0m  %s\n' "$*"; PASS=$((PASS+1)); }
bad()  { printf '  \033[31mFAIL\033[0m  %s\n' "$1"; shift
         for l in "$@"; do printf '        fix: %s\n' "$l"; done; FAIL=$((FAIL+1)); }
warn() { printf '  \033[33mWARN\033[0m  %s\n' "$*"; WARN=$((WARN+1)); }
sec()  { printf '\n%s\n' "$*"; }

echo "=================================================="
echo "  preflight -- $ROOT"
echo "=================================================="

# ---------------------------------------------------------------- 1. toolchain
sec "1. interpreter and benchmarks"

if ( . "$ROOT/scripts/env.sh" ) >/dev/null 2>&1; then
    . "$ROOT/scripts/env.sh" >/dev/null 2>&1
    ok "env.sh found PY=$PY"
    ok "env.sh found BM=$BM"
else
    . "$ROOT/scripts/env.sh" || true
    bad "env.sh could not locate the interpreter or the benchmarks" \
        "ls -d /root/*/baseline/scripts/venv/cpython3.10-*" \
        "export PY=<that>/bin/python BM=<dir containing bm_nbody>"
    echo; echo "Cannot continue without these."; exit 1
fi

V=$("$PY" -c 'import sys;print("%d.%d"%sys.version_info[:2])' 2>/dev/null)
[ "$V" = "3.10" ] && ok "interpreter is Python $V" \
                  || bad "interpreter reports Python '$V', expected 3.10"

DBG=$("$PY" -c 'import sysconfig;print(sysconfig.get_config_var("Py_DEBUG"))' 2>/dev/null)
if [ "$DBG" = "1" ]; then
    ok "interpreter is a --with-pydebug build (as the reports assume)"
else
    warn "interpreter is NOT a debug build (Py_DEBUG=$DBG).
        Every debug-overhead figure in the reports assumes it is.
        If this is deliberate, the reports need that noted."
fi

for b in bm_nbody bm_pyflate; do
    [ -f "$BM/$b/run_benchmark.py" ] && ok "$b installed" \
        || bad "$BM/$b/run_benchmark.py missing" \
               "python3-dbg -m pyperformance venv create"
done

DATA="$BM/bm_pyflate/data/interpreter.tar.bz2"
if [ -f "$DATA" ]; then
    ok "pyflate data file present ($(du -h "$DATA" | cut -f1))"
else
    bad "pyflate data file missing at $DATA" \
        "find / -name interpreter.tar.bz2 2>/dev/null"
fi

# ------------------------------------------------------------------- 2. tools
sec "2. tools"

for t in perf gcc git iverilog; do
    command -v "$t" >/dev/null 2>&1 && ok "$t: $(command -v $t)" \
        || bad "$t not installed" "apt-get install -y $t"
done

"$PY" -c 'import Cython' 2>/dev/null && ok "Cython importable by \$PY" \
    || bad "Cython not available to the measurement interpreter" \
           "$PY -m pip install Cython"

AVAIL=$(df -Pk "$ROOT" | awk 'NR==2{print int($4/1024)}')
if [ "$AVAIL" -ge 1000 ]; then ok "disk: ${AVAIL} MB free"
elif [ "$AVAIL" -ge 400 ]; then warn "disk: only ${AVAIL} MB free; dwarf captures need ~250 MB"
else bad "disk: only ${AVAIL} MB free" "rm -rf ~/sw-project/opt/*.perf.data"; fi

# ------------------------------------------------- 3. the Python.h trap
sec "3. C extension build (the Python.h trap)"

cat > "$TMP/probe.c" <<'EOF'
#include <Python.h>
static PyMethodDef M[] = {{NULL,NULL,0,NULL}};
static struct PyModuleDef D = {PyModuleDef_HEAD_INIT,"probe",NULL,-1,M};
PyMODINIT_FUNC PyInit_probe(void){ return PyModule_Create(&D); }
EOF

INC=$("$PY" -c 'import sysconfig;print(sysconfig.get_paths()["include"])')
SIB=${INC%d}
GCCINC="-I$INC"
[ "$SIB" != "$INC" ] && [ -d "$SIB" ] && GCCINC="$GCCINC -I$SIB"

if gcc -shared -fPIC $GCCINC "$TMP/probe.c" -o "$TMP/probe.so" 2>"$TMP/gcc.err"; then
    ok "compiles against the debug interpreter's headers"
    [ "$SIB" != "$INC" ] && [ -d "$SIB" ] && \
        ok "Python.h found via the sibling include dir ($SIB)"
else
    bad "cannot compile a C extension for this interpreter" \
        "apt-get install -y python3.10-dev python3.10-dbg" \
        "then re-run this script"
    sed 's/^/        /' "$TMP/gcc.err" | head -5
fi

# ------------------------------------------------ 4. the zero-samples trap
sec "4. perf (counters, and the zero-samples trap)"

SPIN='x=0
for i in range(4000000): x+=i'

if perf stat -e instructions -- "$PY" -c "$SPIN" 2>"$TMP/stat.err" >/dev/null; then
    N=$(grep -oE '^ *[0-9][0-9,]*' "$TMP/stat.err" | head -1 | tr -d ' ,')
    if [ -n "${N:-}" ] && [ "$N" -gt 0 ] 2>/dev/null; then
        ok "perf stat counts instructions ($N on a spin loop)"
    else
        bad "perf stat ran but returned no instruction count" \
            "check perf_event_paranoid: cat /proc/sys/kernel/perf_event_paranoid"
    fi
else
    bad "perf stat failed" "echo 1 > /proc/sys/kernel/perf_event_paranoid"
fi

perf record -e cpu-clock -F 199 -g -o "$TMP/a.data" -- \
    "$PY" -c "$SPIN" >/dev/null 2>&1
SA=$(perf script -i "$TMP/a.data" 2>/dev/null | grep -c . || true)
if [ "${SA:-0}" -gt 0 ]; then
    ok "perf record -e cpu-clock captures samples ($SA lines)"
else
    bad "perf record -e cpu-clock captured ZERO samples" \
        "echo 100000 > /proc/sys/kernel/perf_event_max_sample_rate" \
        "echo 1 > /proc/sys/kernel/perf_event_paranoid"
fi

perf record -F 199 -g -o "$TMP/b.data" -- "$PY" -c "$SPIN" >/dev/null 2>&1
SB=$(perf script -i "$TMP/b.data" 2>/dev/null | grep -c . || true)
if [ "${SB:-0}" -eq 0 ]; then
    ok "perf record WITHOUT -e captures zero samples -- the documented trap,
        reproduced. This is why every script names -e cpu-clock."
else
    warn "perf record without -e captured $SB samples on this boot.
        The guest's fallback is behaving today. The scripts name
        -e cpu-clock anyway, which is what makes them deterministic."
fi

RATE=$(cat /proc/sys/kernel/perf_event_max_sample_rate 2>/dev/null || echo 0)
[ "$RATE" -ge 199 ] && ok "perf_event_max_sample_rate = $RATE" \
    || bad "sample rate is $RATE, too low for -F 199" \
           "echo 100000 > /proc/sys/kernel/perf_event_max_sample_rate"

# ------------------------------------------------------------- 5. the RTL
sec "5. hardware"

if command -v iverilog >/dev/null 2>&1; then
    if iverilog -o "$TMP/tb" -g2005 "$ROOT/hardware/mtf_unit.v" \
            "$ROOT/hardware/tb_mtf_unit.v" 2>"$TMP/iv.err"; then
        ok "mtf_unit.v and its testbench compile"
    else
        if grep -qi 'stim_params\|readmemh\|cannot open' "$TMP/iv.err"; then
            ok "RTL compiles; stimulus not generated yet (hardware/Makefile does that)"
        else
            bad "iverilog failed to compile the RTL"
            sed 's/^/        /' "$TMP/iv.err" | head -5
        fi
    fi
fi

# --------------------------------------------------------------- 6. the repo
sec "6. repository"

[ -d "$ROOT/.git" ] && ok "git repository initialized" \
    || bad "not a git repository" "cd $ROOT && git init && git branch -M main"

EMAIL=$(git config --global user.email 2>/dev/null || true)
if [ -n "$EMAIL" ]; then ok "git identity: $EMAIL"
else bad "git identity not set -- commits would be authored by root@$(hostname).(none)" \
         'git config --global user.name "Your Name"' \
         'git config --global user.email "your-github-email"'; fi

if git -C "$ROOT" remote get-url origin >/dev/null 2>&1; then
    ok "origin: $(git -C "$ROOT" remote get-url origin)"
else
    warn "no origin remote; you will not be able to push"
fi

MISS=""
for f in .gitignore README.md report_nbody.txt report_pyflate.txt \
         script_nbody.sh script_pyflate.sh docs/measurement_method_note.txt \
         scripts/env.sh scripts/measure.sh scripts/nbody_opt3_regression.sh \
         scripts/verify_nbody.py scripts/verify_pyflate.py \
         hardware/mtf_unit.v hardware/tb_mtf_unit.v hardware/gen_stimulus.py; do
    [ -f "$ROOT/$f" ] || MISS="$MISS $f"
done
[ -z "$MISS" ] && ok "all scaffold files present" \
    || bad "missing from the scaffold:$MISS" "re-extract codesign_repo.tar.gz"

for v in bm_nbody_opt1 bm_nbody_opt2 bm_nbody_opt3_cython \
         bm_pyflate_opt1 bm_pyflate_opt2; do
    [ -f "$ROOT/benchmarks/$v/run_benchmark.py" ] || MISS="$MISS benchmarks/$v"
done
[ -d "$ROOT/env" ] && [ -n "$(ls "$ROOT/env" 2>/dev/null | grep -v gitkeep)" ] \
    && ok "env/ has the VM audit" \
    || warn "env/ is empty -- copy vm_audit_*.txt from the old clone"

[ -n "$(ls "$ROOT/results/_first_baseline" 2>/dev/null)" ] \
    && ok "results/_first_baseline/ has the contaminated measurement" \
    || warn "results/_first_baseline/ empty -- both reports cite those four files"

# -------------------------------------------------------------------- verdict
echo
echo "=================================================="
printf "  %d passed, %d warnings, %d failures\n" "$PASS" "$WARN" "$FAIL"
echo "=================================================="
if [ "$FAIL" -eq 0 ]; then
    echo "  Nothing blocking. Next: ./script_nbody.sh setup"
    exit 0
else
    echo "  Fix the failures above before starting the run."
    exit 1
fi
