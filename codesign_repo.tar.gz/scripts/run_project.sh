#!/bin/bash
# Drive the whole project: measure, then commit, one step at a time, resumable.
#
#   scripts/run_project.sh status      what is done and what is next
#   scripts/run_project.sh next        run the next pending step, then stop
#   scripts/run_project.sh all         run until something needs a human
#   scripts/run_project.sh step 07     re-run one step (must be the next one)
#   scripts/run_project.sh reset       forget progress (does NOT touch git)
#
# WHY THIS EXISTS
#
# The commit sequence is 16 steps of `git add <exact files>` followed by a
# multi-line message. Typing those by hand is the least interesting and most
# error-prone part of the project: one wrong path and a commit contains the
# wrong files, and you find out after pushing.
#
# It also solves a problem hand-editing cannot. The commit messages quote the
# measured improvement. On a fresh run those numbers change, so this script
# reads each result as it is produced and writes the REAL figure into the
# message. Nothing here can claim an improvement that was not measured.
#
# WHAT IT DOES NOT DO
#
# It does not push, it does not edit the reports, and it stops at every point
# where you should look at something yourself: after setup, after the flame
# graphs, after the RTL simulation, and before the final commit.
set -u

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT" || exit 1
. "$ROOT/scripts/env.sh"

STATE="$ROOT/.project_progress"
touch "$STATE"

done_p()  { grep -qx "$1" "$STATE"; }
mark()    { echo "$1" >> "$STATE"; }
say()     { printf '\n\033[1m== %s\033[0m\n' "$*"; }
die()     { printf '\n\033[31mSTOP: %s\033[0m\n' "$*"; exit 1; }
human()   { printf '\n\033[33m-- needs you: %s\033[0m\n' "$*"; }

# ---------------------------------------------------------------- numbers ---
# Read a measured figure out of results/<variant>/. Prints a bare number.
#   metric mean_s   seconds per call, from the pyperf mean
#   metric instr    instructions, from the first perf stat group
# metric <variant> <field>
#   mean_s   seconds PER CALL, from the pyperf mean
#   instr    instructions PER CALL
#
# perf stat counts a whole process, and that process performs N+1 benchmark
# calls (-w 1 -n N: one warmup plus N timed). The raw counter is therefore a
# TOTAL and has to be divided by the call count before it can sit next to a
# per-call time. N is read back out of the command line perf records in
# stat.txt, so this cannot drift from the flags actually used.
metric() {
    "$PY" - "$ROOT/results/$1" "$2" <<'PYEOF'
import os, re, sys
d, field = sys.argv[1], sys.argv[2]

def read(name):
    with open(os.path.join(d, name)) as f:
        return f.read()

if field == "mean_s":
    m = re.findall(r"Mean \+- std dev: *([\d.]+) *(\w+)", read("timing.txt"))
    if not m: sys.exit("no mean in timing.txt")
    v, u = m[-1]
    print(float(v) * {"ns":1e-9,"us":1e-6,"ms":1e-3,"sec":1.0,"s":1.0}[u])
else:
    t = read("stat.txt")
    m = re.search(r"^\s*([\d,]+)\s+instructions", t, re.M)
    if not m: sys.exit("no instruction count in stat.txt")
    total = int(m.group(1).replace(",", ""))

    n = re.search(r"-n\s+(\d+)", t)
    if n:
        calls = int(n.group(1)) + 1
    elif "pyflate" in d:
        calls = 21
    else:
        calls = 101
    if field == "instr_total":
        print(total)
    else:
        print(total / calls)
PYEOF
}

# Human-readable time, and a signed percentage change from baseline.
fmt_t()  { "$PY" -c "v=float('$1');print('%.3g s'%v if v>=1 else '%.3g ms'%(v*1e3))"; }
fmt_g()  { "$PY" -c "print('%.3f G'%(float('$1')/1e9))"; }
delta()  { "$PY" -c "b,n=float('$1'),float('$2');print('%+.1f%%'%(100*(n-b)/b))"; }

# Measure a variant, then commit its results with the real numbers in the
# message.
#   $1 variant dir   $2 -n value   $3 result name   $4 previous variant ("" if
#   the baseline is the previous one)   $5 prose paragraph
#
# The variants are cumulative, so two comparisons matter and they can disagree:
# against the BASELINE, which is what the 7% requirement is measured on, and
# against the PREVIOUS variant, which is what this change actually did. opt2 on
# nbody is the case that makes the distinction worth the extra lines.
measure_and_commit() {
    local dir=$1 n=$2 name=$3 prev=$4 prose=$5
    ./scripts/measure.sh "$dir" "$n" || die "measurement failed for $name"

    local bname="bm_nbody"; case "$name" in bm_pyflate*) bname="bm_pyflate";; esac
    local bt bi nt ni dt di
    bt=$(metric "$bname" mean_s) || die "cannot read the $bname baseline"
    bi=$(metric "$bname" instr)  || die "cannot read the $bname baseline"
    nt=$(metric "$name"  mean_s) || die "cannot read $name"
    ni=$(metric "$name"  instr)  || die "cannot read $name"
    dt=$(delta "$bt" "$nt"); di=$(delta "$bi" "$ni")

    local extra="" verdict="vs baseline: time $dt, instructions $di"
    if [ -n "$prev" ]; then
        local pt pi pdt pdi
        pt=$(metric "$prev" mean_s) || die "cannot read $prev"
        pi=$(metric "$prev" instr)  || die "cannot read $prev"
        pdt=$(delta "$pt" "$nt"); pdi=$(delta "$pi" "$ni")
        extra="
Against $prev, the change this variant actually makes:
time $pdt, instructions $pdi  ($(fmt_t "$nt") against $(fmt_t "$pt")).
"
        case "$pdt" in +*) verdict="SLOWER than $prev ($pdt); vs baseline $dt";; esac
    fi

    git add "results/$name" || die "git add failed"
    git commit -q -m "$name results: $verdict

$(fmt_t "$nt") per call against $(fmt_t "$bt") at baseline.
$(fmt_g "$ni") instructions against $(fmt_g "$bi").
$extra
$prose" || die "commit failed"
    printf '  committed: %s  (%s)\n' "$name" "$verdict"
}

# ------------------------------------------------------------------ steps ---
step_01() {
    say "01  .gitignore"
    git add .gitignore
    git commit -q -m "Add .gitignore

Excludes perf captures, Cython build products and HDL simulation output.
These are large, binary and regenerated by the scripts."
}

step_02() {
    say "02  guest environment"
    [ -n "$(ls env/ 2>/dev/null | grep -v gitkeep)" ] || \
        die "env/ is empty. Copy vm_audit_*.txt into it first."
    git add env/
    git commit -q -m "Record the QEMU guest environment

1 vCPU, Intel Xeon E5-2630 v3, CPython 3.10.12 built --with-pydebug.
The debug build and the single vCPU both affect every number that follows."
}

step_03() {
    say "03  measurement harness"
    git add scripts/env.sh scripts/measure.sh \
            scripts/verify_nbody.py scripts/verify_pyflate.py \
            scripts/nbody_opt3_regression.sh
    git commit -q -m "Add measurement harness

env.sh locates the debug interpreter and the installed benchmarks instead of
hard-coding them: the venv directory name contains a hash of the interpreter
and its requirements, so it changes whenever the venv is rebuilt.

perf is pointed at a single pyperf worker with -l 1 -w 1 -n N rather than at
pyperformance run. A full run starts ~27 processes (pip, manager, 21 workers)
and perf counts all of them; for nbody only 77.9% of that was benchmark code,
inflating per-call instruction counts by 15.9%.

Flags are locked per benchmark so counters stay comparable across variants.
Verification scripts check each variant against its baseline before timing:
nbody against the original final energy, pyflate against the benchmark's MD5.

nbody_opt3_regression.sh exists because the Cython variant runs in ~4 ms per
call, at which point process startup is larger than the benchmark itself and
total/(N+1) measures Python starting up rather than the optimization."
}

step_04() {
    say "04  optimization variants"
    git add benchmarks/
    git commit -q -m "Add five optimization variants

nbody: hoist indexed reads; math.sqrt in place of pow; Cython typed core.
pyflate: in-place move-to-front; table-driven Huffman decode.
Each is cumulative on the one before it."
}

step_05() {
    say "05  setup and correctness  (~4 min, no commit)"
    ./script_nbody.sh setup   || die "nbody setup failed -- do not continue"
    ./script_pyflate.sh setup || die "pyflate setup failed -- do not continue"
    human "both stages must have printed PASS above.
   nbody variants are checked against the original's final energy after 20,000
   timesteps; pyflate variants against the MD5 the benchmark itself asserts.
   If either did not say PASS, stop here."
}

step_06() {
    say "06  baselines  (~25 min)"
    ./scripts/measure.sh "$BM/bm_nbody"  100 || die "nbody baseline failed"
    ./scripts/measure.sh "$BM/bm_pyflate" 20 || die "pyflate baseline failed"
    local nt ni pt pi
    nt=$(metric bm_nbody mean_s);  ni=$(metric bm_nbody instr)
    pt=$(metric bm_pyflate mean_s); pi=$(metric bm_pyflate instr)
    git add results/
    git commit -q -m "Baseline measurements for nbody and pyflate

nbody   $(fmt_t "$nt") per call, $(fmt_g "$ni") instructions.
pyflate $(fmt_t "$pt") per call, $(fmt_g "$pi") instructions.

_first_baseline/ holds the earlier measurement taken with perf wrapped around
the whole pyperformance run, kept so the method comparison in the reports can
be verified against it."
    printf '\n  baseline nbody   %s   %s\n' "$(fmt_t "$nt")" "$(fmt_g "$ni")"
    printf '  baseline pyflate %s   %s\n'   "$(fmt_t "$pt")" "$(fmt_g "$pi")"
}

step_07() {
    say "07  nbody opt1  (~9 min)"
    measure_and_commit ./benchmarks/bm_nbody_opt1 100 bm_nbody_opt1 "" \
"Hoisting the three indexed reads of each velocity vector into locals removes
repeated sequence element access and index-to-C-integer conversion from the
inner pair loop. Bit-identical output."
}

step_08() {
    say "08  nbody opt2  (~8 min)"
    measure_and_commit ./benchmarks/bm_nbody_opt2 100 bm_nbody_opt2 bm_nbody_opt1 \
"math.sqrt in place of the generic pow. The arithmetic does get cheaper, but
expressing it in Python costs a call, a global lookup and two extra boxed
temporaries per pair iteration. Kept as a measured result, not reverted: a
change that reaches its predicted arithmetic saving and still loses is the
clearest evidence in this project that the arithmetic is not the bottleneck."
}

step_09() {
    say "09  nbody opt3 (Cython)  (~2 min)"
    ./scripts/measure.sh ./benchmarks/bm_nbody_opt3_cython 100 \
        || die "opt3 measurement failed"
    ./scripts/nbody_opt3_regression.sh || die "opt3 regression failed"
    local bt bi nt
    bt=$(metric bm_nbody mean_s); bi=$(metric bm_nbody instr)
    nt=$(metric bm_nbody_opt3_cython mean_s)
    git add results/bm_nbody_opt3_cython
    local p2; p2=$(metric bm_nbody_opt2 mean_s)
    git commit -q -m "nbody opt3 results: time $(delta "$bt" "$nt") vs baseline

$(fmt_t "$nt") per call against $(fmt_t "$bt") at baseline,
and $(delta "$p2" "$nt") against bm_nbody_opt2 ($(fmt_t "$p2")).

Per-call figures for this variant come from the slope of instructions against
call count across three values of N, not from total/(N+1): at this speed
process startup is a larger share of a fixed-work run than the benchmark is.
regression.txt records the fit, the held-out point and the error."
    human "read results/bm_nbody_opt3_cython/regression.txt now.
   The held-out point should be predicted to within about 1%, and the time
   slope should agree with the pyperf mean to a few percent. If either is far
   out, something moved during the run."
}

step_10() {
    say "10  pyflate opt1  (~14 min)"
    measure_and_commit ./benchmarks/bm_pyflate_opt1 20 bm_pyflate_opt1 "" \
"move_to_front rebuilt the list with three slices and a concatenation on every
call. l.insert(0, l.pop(c)) does the same rotation in place. Verified against
the benchmark's own MD5 digest."
}

step_11() {
    say "11  pyflate opt2  (~13 min)"
    measure_and_commit ./benchmarks/bm_pyflate_opt2 20 bm_pyflate_opt2 bm_pyflate_opt1 \
"find_next_symbol scanned the symbol table linearly, touching three Python
attributes per candidate. self.table is already sorted by (bits, code), so
grouping it by code length preserves the search order while replacing the scan
with one dict lookup per distinct length. Verified against the same MD5."
}

step_12() {
    say "12  flame graphs  (~22 min)"
    ./script_nbody.sh flamegraph   || die "nbody flame graph failed"
    ./script_pyflate.sh flamegraph || die "pyflate flame graph failed"
    git add scripts/cleanup_measurements.sh results/_flamegraph
    git commit -q -m "Add flame graphs for both benchmarks

Recorded with --call-graph dwarf; frame-pointer unwinding is unusable on this
-Og interpreter build. Flat profile percentages are unaffected by that, so the
bottleneck figures in the reports stand either way."
    human "open results/_flamegraph/flamegraph_nbody.svg in a browser.
   You should see named Python and CPython frames stacked above the eval loop.
   If you see hex addresses, the unwinding failed -- say so before continuing."
}

step_13() {
    say "13  accelerator RTL"
    ( cd hardware && make ) || die "iverilog simulation failed"
    human "the simulation above must have printed
     issued : 89837   checked : 89837   mismatches : 0
     RESULT: PASS -- output stream matches pyflate exactly"
    git add hardware/mtf_unit.v
    git commit -q -m "Add move-to-front accelerator RTL

256 x 8-bit table in flops, N:1 read mux, conditional parallel shift network,
9-bit bounds comparator, two-state control FSM. One operation per cycle, one
cycle of latency. Replaces ~20,000 executed instructions per MTF operation."
}

step_14() {
    say "14  testbench and stimulus generator"
    git add hardware/tb_mtf_unit.v hardware/gen_stimulus.py hardware/Makefile
    git commit -q -m "Add accelerator testbench and stimulus generator

gen_stimulus.py instruments move_to_front during a real decode and captures
all 89,837 (index, symbol) pairs. The testbench streams them back to back and
compares every response against the value Python produced, plus reset, arming
and bounds-check coverage.

Result: 89837 issued, 89837 checked, 0 mismatches."
}

step_15() {
    say "15  accelerator specification"
    git add hardware/README.md
    git commit -q -m "Add accelerator specification

Port table with data widths, 200 MHz single-cycle target, datapath and control
description, two integration options (custom instruction and AXI4-Lite), area
estimate from cell counts.

Amdahl bound stated plainly: the unit makes its target far faster and the
benchmark only slightly faster, because the target is a minority of runtime."
}

step_16() {
    say "16  pipeline scripts"
    git add script_nbody.sh script_pyflate.sh
    git commit -q -m "Add per-benchmark pipeline scripts

Each covers setup with dependency installation, baseline and optimized
execution, flame graph generation and a performance comparison, as the
specification requires. script_pyflate.sh additionally runs the RTL
simulation."
}

step_17() {
    say "17  reports, README, prompts  (final commit)"
    [ -f prompt.txt ] || die "prompt.txt does not exist. The specification requires it."
    if grep -q "your name(s) and ID(s)" README.md; then
        die "README.md line 7 still says 'your name(s) and ID(s)'. Fill it in."
    fi
    human "have the report figures been updated to THIS run's numbers?
   If not, stop: run scripts/collect_results.sh and send the tarball first.
   Committing reports that disagree with the committed results is the one
   thing a careful grader will catch.
   When they are updated, re-run this step to finish."
    [ "${I_UPDATED_THE_REPORTS:-}" = "yes" ] || \
        die "re-run as:  I_UPDATED_THE_REPORTS=yes scripts/run_project.sh next"
    rm -f COMMITS.txt RUN_FROM_SCRATCH.txt
    git add report_nbody.txt report_pyflate.txt README.md prompt.txt \
            docs/measurement_method_note.txt
    git commit -q -m "Add benchmark reports, README and AI prompt log"
    say "all 16 commits done. Check, then push:"
    cat <<'EOF'
    git log --oneline
    git ls-files | grep -E 'perf.data|\.so$'    # must print nothing
    du -sh .git
    git push -u origin main
EOF
}

STEPS="01 02 03 04 05 06 07 08 09 10 11 12 13 14 15 16 17"
LABEL_01=".gitignore";          LABEL_02="guest environment"
LABEL_03="measurement harness"; LABEL_04="optimization variants"
LABEL_05="setup + correctness"; LABEL_06="baselines"
LABEL_07="nbody opt1";          LABEL_08="nbody opt2"
LABEL_09="nbody opt3";          LABEL_10="pyflate opt1"
LABEL_11="pyflate opt2";        LABEL_12="flame graphs"
LABEL_13="accelerator RTL";     LABEL_14="testbench"
LABEL_15="accelerator spec";    LABEL_16="pipeline scripts"
LABEL_17="reports + README"

next_step() { for s in $STEPS; do done_p "$s" || { echo "$s"; return; }; done; }

case "${1:-status}" in
  status)
    echo "step  state     what"
    for s in $STEPS; do
        eval "l=\$LABEL_$s"
        if done_p "$s"; then printf '  %s  done      %s\n' "$s" "$l"
        else                 printf '  %s  pending   %s\n' "$s" "$l"; fi
    done
    n=$(next_step)
    [ -n "$n" ] && echo && echo "next: scripts/run_project.sh next   ($n)" \
                || echo && echo "all steps complete"
    ;;
  next|all)
    while :; do
        s=$(next_step)
        [ -n "$s" ] || { say "all steps complete"; break; }
        "step_$s" || exit 1
        mark "$s"
        [ "$1" = "next" ] && break
        case "$s" in 05|09|12|13|17) say "stopping: the step above needs you"; break;; esac
    done
    ;;
  step)
    s=${2:-}; n=$(next_step)
    [ "$s" = "$n" ] || die "step $s is not next; next is $n (use reset to redo earlier steps)"
    "step_$s" && mark "$s"
    ;;
  reset) : > "$STATE"; echo "progress cleared (git history untouched)";;
  *) sed -n '2,25p' "$0";;
esac
