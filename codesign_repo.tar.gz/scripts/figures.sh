#!/bin/bash
# Print the measured figures for a variant, ready to paste into a commit.
#
#   scripts/figures.sh <variant> [previous-variant]
#
#   scripts/figures.sh bm_nbody_opt1
#   scripts/figures.sh bm_nbody_opt2 bm_nbody_opt1
#
# WHY
#
# The commit messages in RUN_FROM_SCRATCH.txt quote improvements from an
# EARLIER run. If you paste them verbatim after re-measuring, the history
# claims numbers that your own committed results/ contradict -- which is worse
# than having no numbers in the message at all. This reads the figures you just
# measured, so what you paste is what happened.
#
# The variants are cumulative, so two comparisons matter and they can disagree:
# against the baseline (what the 7% requirement is measured on) and against the
# previous variant (what this change actually did). Pass the previous variant
# as a second argument whenever there is one.
set -u

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
. "$ROOT/scripts/env.sh"

NAME=${1:-}
PREV=${2:-}
[ -n "$NAME" ] || { sed -n '2,10p' "$0"; exit 1; }
[ -d "$ROOT/results/$NAME" ] || { echo "no results/$NAME -- measure it first"; exit 1; }

# metric <variant> <field>
#   mean_s   seconds PER CALL, from the pyperf mean
#   instr    instructions PER CALL
#
# perf stat counts a whole process, and that process performs N+1 benchmark
# calls (-w 1 -n N: one warmup plus N timed). The raw counter is therefore a
# TOTAL and has to be divided by the call count before it can sit next to a
# per-call time. N is read back out of the command line perf records in
# stat.txt, so this cannot drift from the flags actually used.
metric() {
    "$PY" - "$ROOT/results/$1" "$2" <<'PYEOF'
import os, re, sys
d, field = sys.argv[1], sys.argv[2]

def read(name):
    with open(os.path.join(d, name)) as f:
        return f.read()

if field == "mean_s":
    m = re.findall(r"Mean \+- std dev: *([\d.]+) *(\w+)", read("timing.txt"))
    if not m: sys.exit("no mean in timing.txt")
    v, u = m[-1]
    print(float(v) * {"ns":1e-9,"us":1e-6,"ms":1e-3,"sec":1.0,"s":1.0}[u])
else:
    t = read("stat.txt")
    m = re.search(r"^\s*([\d,]+)\s+instructions", t, re.M)
    if not m: sys.exit("no instruction count in stat.txt")
    total = int(m.group(1).replace(",", ""))

    n = re.search(r"-n\s+(\d+)", t)
    if n:
        calls = int(n.group(1)) + 1
    elif "pyflate" in d:
        calls = 21
    else:
        calls = 101
    if field == "instr_total":
        print(total)
    else:
        print(total / calls)
PYEOF
}
fmt_t() { "$PY" -c "v=float('$1');print('%.3g s'%v if v>=1 else '%.3g ms'%(v*1e3))"; }
fmt_g() { "$PY" -c "print('%.3f G'%(float('$1')/1e9))"; }
delta() { "$PY" -c "b,n=float('$1'),float('$2');print('%+.1f%%'%(100*(n-b)/b))"; }

BASE=bm_nbody; case "$NAME" in bm_pyflate*) BASE=bm_pyflate;; esac

nt=$(metric "$NAME" mean_s) || exit 1
ni=$(metric "$NAME" instr)  || exit 1

if [ "$NAME" = "$BASE" ]; then
    tot=$(metric "$NAME" instr_total)
    echo "$NAME  $(fmt_t "$nt") per call, $(fmt_g "$ni") instructions per call"
    echo "         (perf counted $(fmt_g "$tot") for the whole process; that is"
    echo "          the N+1 calls the worker makes, divided out above)"
    exit 0
fi

bt=$(metric "$BASE" mean_s) || exit 1
bi=$(metric "$BASE" instr)  || exit 1
dt=$(delta "$bt" "$nt"); di=$(delta "$bi" "$ni")

SUBJ="$NAME results: vs baseline time $dt, instructions $di"
EXTRA=""
if [ -n "$PREV" ]; then
    pt=$(metric "$PREV" mean_s) || exit 1
    pi=$(metric "$PREV" instr)  || exit 1
    pdt=$(delta "$pt" "$nt"); pdi=$(delta "$pi" "$ni")
    EXTRA="
Against $PREV, the change this variant actually makes:
time $pdt, instructions $pdi  ($(fmt_t "$nt") against $(fmt_t "$pt"))."
    case "$pdt" in +*) SUBJ="$NAME results: SLOWER than $PREV ($pdt); vs baseline $dt";; esac
fi

echo "--------- paste this as the first lines of the commit message ---------"
echo "$SUBJ"
echo
echo "$(fmt_t "$nt") per call against $(fmt_t "$bt") at baseline."
echo "$(fmt_g "$ni") instructions against $(fmt_g "$bi")."
[ -n "$EXTRA" ] && echo "$EXTRA"
echo "-----------------------------------------------------------------------"
echo "then the explanatory paragraph from RUN_FROM_SCRATCH.txt for this step,"
echo "which describes WHAT changed and is still true whatever the numbers are."
