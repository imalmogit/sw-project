#!/bin/bash
# Measure one benchmark variant three ways: timing, counters, profile.
#
#   scripts/measure.sh <benchmark-dir> <N>
#     benchmark-dir : a bm_* directory containing run_benchmark.py
#     N             : the -n value (100 for nbody variants, 20 for pyflate)
#
# N MUST match the baseline for that benchmark, or the instruction counts
# describe a different amount of work and the comparison is meaningless.
set -u

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
. "$ROOT/scripts/env.sh"

DIR=$1
N=$2
NAME=$(basename "$DIR")
OUT="$ROOT/results/$NAME"
mkdir -p "$OUT"

BENCH="$DIR/run_benchmark.py"
[ -f "$BENCH" ] || { echo "no run_benchmark.py in $DIR"; exit 1; }

echo "=============================================="
echo "[*] $NAME   (-l 1 -w 1 -n $N)"
echo "=============================================="

echo "[1/3] timing (pyperf manager, 20 processes, own calibration)..."
$PY -u "$BENCH" -o "$OUT/${NAME}.json" 2>&1 | tee "$OUT/timing.txt"

echo "[2/3] counters (fixed work; 1 vCPU cannot multiplex more than one group)..."
: > "$OUT/stat.txt"
for G in "task-clock,context-switches,page-faults,cycles,instructions" \
         "cache-references,cache-misses" \
         "branches,branch-misses"; do
  echo "=== $G ===" | tee -a "$OUT/stat.txt"
  perf stat -r 3 -e "$G" -- \
      $PY -u "$BENCH" --worker -l 1 -w 1 -n "$N" 2>&1 | tee -a "$OUT/stat.txt"
done

echo "[3/3] profile (cpu-clock named explicitly, or zero samples are captured)..."
perf record -e cpu-clock -F 199 -g -o "$OUT/${NAME}.perf.data" -- \
    $PY -u "$BENCH" --worker -l 1 -w 1 -n "$N"
perf report -i "$OUT/${NAME}.perf.data" --stdio --no-children > "$OUT/report.txt"

echo "[+] done -> results/$NAME/"
grep -E "Mean \+- std dev" "$OUT/timing.txt" | tail -1
grep -E "^ *[0-9].*instructions" "$OUT/stat.txt" | head -1
