#!/bin/bash
# Package every measurement output into one small tarball, and print a digest.
#
#   scripts/collect_results.sh
#
# Produces ~/measurements.tar.gz containing results/ and env/ with the large
# binaries stripped out: no *.perf.data (hundreds of MB), no flame graph SVGs,
# no compiled extensions. What is left is text -- timings, counters, profiles --
# which is everything the reports are derived from.
#
# The digest printed at the end is a quick sanity check: seven variants, each
# with a mean and an instruction count. If a line is missing, that variant was
# not measured.
set -u

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
OUT=${1:-$HOME/measurements.tar.gz}

cd "$ROOT" || exit 1

tar czf "$OUT" \
    --exclude='*.perf.data' \
    --exclude='*.perf.data.old' \
    --exclude='*.svg' \
    --exclude='*.folded' \
    --exclude='*.so' \
    results env 2>/dev/null

echo "=============================================="
echo "  digest"
echo "=============================================="
printf "%-26s %14s %16s\n" "variant" "mean" "instructions"
for d in results/*/; do
  name=$(basename "$d")
  [ "$name" = "_first_baseline" ] && continue
  [ "$name" = "_cleanup" ] && continue

  mean="-"
  if [ -f "$d/timing.txt" ]; then
    mean=$(grep -oE "Mean \+- std dev: [^+]*" "$d/timing.txt" | tail -1 \
           | sed 's/Mean +- std dev: //' | tr -d ' ')
    [ -z "$mean" ] && mean="-"
  fi

  ins="-"
  if [ -f "$d/stat.txt" ]; then
    ins=$(grep -E "^ *[0-9][0-9,.]* *instructions" "$d/stat.txt" | head -1 \
          | awk '{print $1}')
    [ -z "$ins" ] && ins="-"
  fi

  printf "%-26s %14s %16s\n" "$name" "$mean" "$ins"
done

echo
if [ -f results/bm_nbody_opt3_cython/regression.txt ]; then
  echo "opt3 regression: present"
else
  echo "opt3 regression: MISSING -- run scripts/nbody_opt3_regression.sh"
fi
if [ -d results/_cleanup ]; then
  echo "cleanup (dwarf + release comparison): present"
else
  echo "cleanup (dwarf + release comparison): MISSING -- run scripts/cleanup_measurements.sh"
fi
if [ -d results/_first_baseline ]; then
  echo "first (contaminated) baseline: present"
else
  echo "first (contaminated) baseline: MISSING -- the method comparison needs it"
fi

echo
echo "[+] $OUT  ($(du -h "$OUT" | cut -f1))"
echo "    Send this file. Every figure in both reports is derived from it."
