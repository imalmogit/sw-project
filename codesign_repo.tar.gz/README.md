# HW/SW Co-design — nbody & pyflate

Workload analysis, software optimization and a hardware acceleration proposal
for two `pyperformance` benchmarks, measured on the course QEMU guest.

<!-- TODO: names and IDs -->
Authors: _your name(s) and ID(s)_

---

## Results

| Variant | Time per call | vs baseline | Instructions per call | vs baseline |
| --- | --- | --- | --- | --- |
| nbody baseline | 477 ms | | 2.909 G | |
| nbody opt1 — hoist indexed reads | 428 ms | **−10.3%** | 2.663 G | −8.4% |
| nbody opt2 — `sqrt` instead of `pow` | 443 ms | −7.1% | 2.765 G | −4.9% |
| nbody opt3 — Cython typed core | 3.81 ms | **−99.2%** | 0.0197 G | −99.3% |
| pyflate baseline | 3.14 s | | 16.743 G | |
| pyflate opt1 — in-place move-to-front | 2.74 s | **−12.7%** | 14.806 G | −11.6% |
| pyflate opt2 — table-driven Huffman | 2.62 s | **−16.6%** | 14.004 G | −16.4% |

Both benchmarks clear the required 7% threshold.

**Hardware proposal:** a move-to-front accelerator for pyflate's bzip2 decoder,
implemented in Verilog and verified against 89,837 operations captured from a
real decode. It replaces ≈20,000 executed instructions per operation with one
cycle.

Four findings the data supports:

- **Only 11.4% of nbody's runtime is floating-point arithmetic.** The
  interpreter spends 539 instructions per floating-point operation; compiled C
  spends 3.65.
- **opt2 is a measured regression.** It reached its predicted Amdahl ceiling
  exactly — the arithmetic got 2.8% cheaper, which was the whole budget — and
  the program still slowed by 3.5%, because expressing the cheaper formula in
  Python cost more than it saved.
- **20% of pyflate's profile is an artifact of the debug interpreter** and is
  excluded from every bottleneck figure.
- **The accelerator makes its target 751× faster and the benchmark only 1.23×
  faster.** Amdahl's law, stated plainly.

Full analysis: [`report_nbody.txt`](report_nbody.txt),
[`report_pyflate.txt`](report_pyflate.txt).

---

## Repository layout

```
.
├── report_nbody.txt        analysis, optimizations, results, HW proposal
├── report_pyflate.txt      analysis, optimizations, results, HW proposal
├── script_nbody.sh         full pipeline for nbody
├── script_pyflate.sh       full pipeline for pyflate
├── prompt.txt              AI prompts used during the project
├── README.md
│
├── hardware/               the proposed accelerator
│   ├── mtf_unit.v          RTL (Verilog-2005)
│   ├── tb_mtf_unit.v       self-checking testbench
│   ├── gen_stimulus.py     captures vectors from a real bzip2 decode
│   ├── Makefile            `make` = generate, compile, simulate
│   └── README.md           interface, architecture, trade-offs
│
├── benchmarks/             custom benchmark variants
│   ├── bm_nbody_opt1/      hoist indexed reads into locals
│   ├── bm_nbody_opt2/      + sqrt in place of ** -1.5   (regression)
│   ├── bm_nbody_opt3_cython/  + typed C core via Cython
│   ├── bm_pyflate_opt1/    in-place move-to-front
│   └── bm_pyflate_opt2/    + table-driven Huffman decode
│
├── scripts/                measurement harness
│   ├── env.sh              locates the debug interpreter and the benchmarks
│   ├── measure.sh          one variant: timing, counters, profile
│   ├── nbody_opt3_regression.sh  startup vs per-call fit for the Cython variant
│   ├── verify_nbody.py     final-energy check against the original
│   ├── verify_pyflate.py   MD5 check against the benchmark's own digest
│   └── cleanup_measurements.sh   DWARF profiles, release comparison
│
├── results/                measurement outputs, one directory per variant
└── env/                    guest environment audit
```

Each variant is cumulative: opt2 contains opt1, opt3 contains opt2.

---

## Running it

```bash
./script_nbody.sh        # setup, baseline, variants, flame graph, comparison
./script_pyflate.sh      # the same, plus RTL verification
```

Two things live outside this repository and are needed to run it: the CPython
3.10 built `--with-pydebug`, and the installed `pyperformance` benchmark
directory. Every script sources `scripts/env.sh`, which locates both and prints
what it found:

```
[env] PY=/root/sw-project/baseline/scripts/venv/cpython3.10-58f517067257-compat-31b33d68c68a/bin/python
[env] BM=/root/sw-project/venv-dbg/lib/python3.10/site-packages/pyperformance/data-files/benchmarks
```

That venv name encodes a hash of the interpreter and its requirements, so it
changes whenever the venv is rebuilt — which is why the path is searched for
rather than hard-coded. Override the search if yours are elsewhere:

```bash
export PY=/path/to/venv/bin/python
export BM=/path/to/pyperformance/data-files/benchmarks
```

Locate them with `ls -d /root/*/baseline/scripts/venv/cpython3.10-*` or
`python3-dbg -m pyperformance venv show`.

Either script also runs a single stage:

```bash
./script_nbody.sh setup        # deps, Cython build, correctness verification
./script_nbody.sh baseline
./script_nbody.sh optimized
./script_nbody.sh flamegraph
./script_nbody.sh compare
./script_pyflate.sh hardware   # iverilog simulation of the accelerator
```

`setup` refuses to continue if any variant stops producing the correct result —
nbody variants are checked against the original's final energy after 20,000
timesteps, pyflate variants against the MD5 digest the benchmark itself
asserts on.

Each measured variant writes `results/<name>/`:

| File | Contents |
| --- | --- |
| `timing.txt`, `<name>.json` | pyperf mean over 20 processes |
| `stat.txt` | perf stat, three counter groups, three repetitions |
| `report.txt` | perf report, self overhead |
| `<name>.perf.data` | raw profile (not committed) |

`results/bm_nbody_opt3_cython/` additionally holds `regression.txt`. At 3.81 ms
per call, process startup is a larger share of a fixed-work run than the
benchmark is, so `total / (N+1)` over-states the per-call cost by 37%. The
per-call figures for that variant are the slope of instructions against call
count across three values of `N`, produced by:

```bash
./scripts/nbody_opt3_regression.sh
```

### Hardware on its own

```bash
cd hardware && make
```

Requires `iverilog`. Generates stimulus from a real decode, compiles the RTL
and testbench, and simulates. Expected result:

```
  issued     : 89837
  checked    : 89837
  mismatches : 0
  RESULT: PASS -- output stream matches pyflate exactly
```

---

## The flags are locked

**nbody variants use `-l 1 -w 1 -n 100`. pyflate variants use `-l 1 -w 1 -n 20`.
Baselines included.**

`perf stat` counts instructions for a whole process, not per benchmark call. At
`-n 100` the process performs 101 calls; at `-n 20`, 21. Running a variant at a
different `N` makes its counters describe a different amount of work and the
comparison against the baseline becomes meaningless. Do not change these
values without re-running every variant of that benchmark.

---

## Method notes

Three decisions that are not obvious from the commands, each of which cost real
debugging time:

**perf is pointed at a single pyperf worker, not at `pyperformance run`.** The
project guide profiles the whole harness. A `pyperformance run` starts about 27
processes — pyperformance, four pip invocations, the pyperf manager and 21
workers — and perf counts all of them. For nbody only 77.9% of that was
benchmark code, which inflated per-call instruction counts by 15.9%. The
contamination was visible directly in the profile, which contained samples from
`lsb_release`, `dpkg-query` and `uname`. `--worker -l 1 -w 1 -n N` runs one
process doing exactly `N+1` benchmark calls and nothing else.

**Timing and counters come from different runs and are never mixed.** Timing is
the pyperformance mean across 20 processes with randomized memory layout, which
answers *how much faster*. Counters come from the fixed-work worker run, which
answers *which instructions disappeared*.

**`perf record` must name `cpu-clock` explicitly.** The guest exposes an Intel
PMU, so `perf stat` returns real cycle and instruction counts, but it does not
deliver sampling interrupts. Without `-e`, perf opens the hardware `cycles`
event successfully, never falls back to a software event, and captures **zero
samples with no error message**. Flame graphs additionally need
`--call-graph dwarf`, because the `-Og` interpreter build omits frame pointers
and frame-pointer unwinding walks stack garbage.

---

## Known limitations

| Limitation | Effect |
| --- | --- |
| Debug (`--with-pydebug`) interpreter | Debug-only code is 3.7% of the nbody profile and 20.0% of pyflate's, and is excluded from all bottleneck figures |
| Single-vCPU guest | Run-to-run spread is ~1.5% (nbody) and ~2.5% (pyflate); no improvement below ~3% is claimed |
| `kptr_restrict` set | Kernel symbols unresolved, so the analysis is user-space only (~1% of samples) |
| Accelerator not synthesized | Frequency and area are estimates from the critical path and cell counts, not synthesis results. The project specification does not require synthesis |
